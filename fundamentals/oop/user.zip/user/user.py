#User class setup

from signal import sigpending


class User:
    def __init__(self, first_name, last_name, email, age):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.age = age

        #default attributes

        self.is_rewards_member = False
        self.gold_card_points = 0

    #displays user's info on separate lines

    def display_info(self):
        print(self.first_name)
        print(self.last_name)
        print(self.email)
        print(self.age)

    #changing member status and points

    def enroll(self):
        self.is_rewards_member = True
        self.gold_card_points = 200

    #spend points method

    def spend_points(self, amount):
        if amount > self.gold_card_points:
            print('Sorry not enough points')
        else:
            self.gold_card_points = self.gold_card_points - amount

    #membership

    def membership(self):
        if self.is_rewards_member == True:
            print('Would you like to renew membership?')
        else:
            print('Enroll now?')

user1 = User('Chris', 'Choi', 'email', 27)
user2 = User('Preston', 'Choi', 'email', 24)
user3 = User('Morgan', 'Choi', 'email', 21)

# print(User.display_info(user1))


User.enroll(user1)
User.spend_points(user1, 50)

User.enroll(user2)
User.spend_points(user2, 80)

print(User.display_info(user1))
print(user1.is_rewards_member)
print(user1.gold_card_points)

print(User.display_info(user2))
print(user2.gold_card_points)

print(User.display_info(user3))

print(User.membership(user3))
User.spend_points(user3, 40)